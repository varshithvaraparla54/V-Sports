<?php
session_start();
// If already logged in, go straight to the store
if (isset($_SESSION['user_email'])) {
    header('Location: home.php');
    exit;
}

$error   = '';
$success = '';

// ── Handle Login POST ────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    require_once 'db.php';

    if ($_POST['action'] === 'login') {
        $email = trim(mysqli_real_escape_string($conn, $_POST['email'] ?? ''));
        $pass  = trim($_POST['password'] ?? '');

        if (!$email || !$pass) {
            $error = 'Please fill in all fields.';
        } else {
            $res  = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' LIMIT 1");
            $user = mysqli_fetch_assoc($res);
            if ($user && password_verify($pass, $user['password'])) {
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_name']  = $user['name'];
                header('Location: home.php');
                exit;
            } else {
                $error = 'Invalid email or password. Please try again.';
            }
        }

    } elseif ($_POST['action'] === 'register') {
        $name  = trim(mysqli_real_escape_string($conn, $_POST['name']     ?? ''));
        $email = trim(mysqli_real_escape_string($conn, $_POST['email']    ?? ''));
        $pass  = trim($_POST['password'] ?? '');
        $cpass = trim($_POST['confirm_password'] ?? '');

        if (!$name || !$email || !$pass || !$cpass) {
            $error = 'All fields are required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email address.';
        } elseif (strlen($pass) < 6) {
            $error = 'Password must be at least 6 characters.';
        } elseif ($pass !== $cpass) {
            $error = 'Passwords do not match.';
        } else {
            $check = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
            if (mysqli_num_rows($check) > 0) {
                $error = 'This email is already registered. Please login.';
            } else {
                $hash = password_hash($pass, PASSWORD_BCRYPT);
                mysqli_query($conn, "INSERT INTO users (name,email,password) VALUES ('$name','$email','$hash')");
                $success = "Account created successfully! Welcome, $name. Please login.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<meta name="description" content="V² Sports – Login or Register to shop Cricket, Football, Gym and Badminton equipment."/>
<title>V² Sports – Login</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800;900&display=swap" rel="stylesheet"/>
<style>
  :root {
    --accent:  #ff6b00;
    --accent2: #ffd740;
    --green:   #00e676;
    --bg:      #05080f;
    --card:    #0f1928;
    --mid:     #0a1020;
    --text:    #eef2ff;
    --muted:   #7a95b8;
    --sky:     #29b6f6;
    --red:     #ff3d57;
    --r:       12px;
    --t:       0.28s ease;
  }
  *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
  body {
    font-family: 'Outfit', sans-serif;
    background: var(--bg);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    position: relative;
  }

  /* Animated background blobs */
  body::before, body::after {
    content: '';
    position: fixed;
    border-radius: 50%;
    filter: blur(80px);
    opacity: 0.18;
    animation: float 8s ease-in-out infinite alternate;
    z-index: 0;
  }
  body::before {
    width: 600px; height: 600px;
    background: radial-gradient(circle, #ff6b00, transparent 70%);
    top: -150px; left: -150px;
  }
  body::after {
    width: 500px; height: 500px;
    background: radial-gradient(circle, #29b6f6, transparent 70%);
    bottom: -100px; right: -100px;
    animation-delay: -4s;
  }
  @keyframes float {
    from { transform: translate(0,0) scale(1); }
    to   { transform: translate(40px,40px) scale(1.15); }
  }

  /* Logo / brand */
  .brand {
    text-align: center;
    margin-bottom: 28px;
    position: relative; z-index: 1;
  }
  .brand h1 {
    font-size: 42px; font-weight: 900;
    background: linear-gradient(90deg, var(--accent), var(--accent2), var(--green));
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: 2px;
  }
  .brand p { color: var(--muted); font-size: 15px; margin-top: 6px; font-weight: 400; }

  /* Card */
  .card {
    background: rgba(15,25,40,0.8);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255,107,0,0.2);
    border-radius: 20px;
    width: 420px;
    box-shadow: 0 24px 80px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,107,0,0.08);
    position: relative; z-index: 1;
    animation: slideUp 0.5s cubic-bezier(0.34,1.56,0.64,1);
  }
  @keyframes slideUp {
    from { transform: translateY(40px); opacity: 0; }
    to   { transform: translateY(0);    opacity: 1; }
  }

  /* Tabs */
  .tabs {
    display: flex;
    border-bottom: 1px solid rgba(255,107,0,0.15);
  }
  .tab-btn {
    flex: 1; padding: 18px;
    background: none; border: none;
    color: var(--muted); font-family: 'Outfit', sans-serif;
    font-size: 15px; font-weight: 700; cursor: pointer;
    transition: color var(--t), background var(--t);
    border-radius: 0; letter-spacing: 0.5px;
  }
  .tab-btn:first-child { border-radius: 20px 0 0 0; }
  .tab-btn:last-child  { border-radius: 0 20px 0 0; }
  .tab-btn.active {
    color: var(--accent);
    background: rgba(255,107,0,0.07);
    border-bottom: 2px solid var(--accent);
  }
  .tab-btn:hover:not(.active) { color: var(--text); background: rgba(255,255,255,0.03); }

  /* Form panels */
  .panel { display: none; padding: 30px 32px 32px; }
  .panel.active { display: block; }

  .panel h2 { font-size: 22px; color: var(--text); font-weight: 800; margin-bottom: 6px; }
  .panel .sub { color: var(--muted); font-size: 13px; margin-bottom: 22px; }

  .field { margin-bottom: 16px; }
  .field label { display: block; font-size: 13px; color: var(--muted); margin-bottom: 6px; font-weight: 600; }
  .field input {
    width: 100%; padding: 13px 16px;
    background: rgba(10,16,32,0.9);
    border: 1.5px solid rgba(255,107,0,0.18);
    border-radius: var(--r); color: var(--text);
    font-size: 14px; font-family: 'Outfit', sans-serif;
    outline: none; transition: border-color var(--t), box-shadow var(--t);
  }
  .field input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px rgba(255,107,0,0.12);
  }
  .field input::placeholder { color: rgba(122,149,184,0.6); }

  .submit-btn {
    width: 100%; padding: 14px;
    background: linear-gradient(135deg, var(--accent), #ff9040);
    color: #fff; border: none; border-radius: var(--r);
    font-family: 'Outfit', sans-serif;
    font-size: 16px; font-weight: 800; cursor: pointer;
    letter-spacing: 0.5px;
    box-shadow: 0 6px 24px rgba(255,107,0,0.4);
    transition: transform var(--t), box-shadow var(--t);
    margin-top: 6px;
  }
  .submit-btn:hover { transform: translateY(-2px); box-shadow: 0 10px 32px rgba(255,107,0,0.6); }
  .submit-btn:active { transform: scale(0.97); }

  /* Alert messages */
  .alert {
    padding: 12px 16px; border-radius: var(--r);
    font-size: 13px; font-weight: 600;
    margin-bottom: 18px; display: flex; align-items: center; gap: 8px;
  }
  .alert-error   { background: rgba(255,61,87,0.12); color: #ff7a8a; border: 1px solid rgba(255,61,87,0.25); }
  .alert-success { background: rgba(0,230,118,0.1);  color: var(--green); border: 1px solid rgba(0,230,118,0.25); }

  /* Footer note */
  .footer-note {
    text-align: center; color: var(--muted);
    font-size: 12px; margin-top: 20px;
    position: relative; z-index: 1;
  }

  /* Sports icons row */
  .sports-row {
    display: flex; gap: 18px; justify-content: center;
    font-size: 28px; margin-bottom: 24px;
    position: relative; z-index: 1;
    animation: fadeIn 1s ease 0.3s both;
  }
  @keyframes fadeIn { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:none; } }
  .sports-row span { cursor: default; transition: transform 0.2s; display: inline-block; }
  .sports-row span:hover { transform: scale(1.3) rotate(-5deg); }

  @media (max-width: 460px) {
    .card { width: 95%; }
    .panel { padding: 24px 20px 28px; }
  }
</style>
</head>
<body>

<div class="brand">
  <h1>V² Sports</h1>
  <p>Your one-stop shop for all sports equipment</p>
</div>

<div class="sports-row">
  <span title="Cricket">🏏</span>
  <span title="Football">⚽</span>
  <span title="Gym">🏋️</span>
  <span title="Badminton">🏸</span>
  <span title="Basketball">🏀</span>
  <span title="Running">👟</span>
</div>

<div class="card">
  <!-- Tabs -->
  <div class="tabs">
    <button class="tab-btn active" onclick="switchTab('login')"  id="tab-login">🔑 Login</button>
    <button class="tab-btn"        onclick="switchTab('signup')" id="tab-signup">🚀 Sign Up</button>
  </div>

  <!-- LOGIN PANEL -->
  <div class="panel active" id="panel-login">
    <h2>Welcome back!</h2>
    <p class="sub">Login to continue shopping</p>

    <?php if ($error && (!isset($_POST['action']) || $_POST['action']==='login')): ?>
      <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
      <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php">
      <input type="hidden" name="action" value="login">
      <div class="field">
        <label>Email Address</label>
        <input type="email" name="email" placeholder="you@example.com" required
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" autocomplete="email"/>
      </div>
      <div class="field">
        <label>Password</label>
        <input type="password" name="password" placeholder="Enter your password" required autocomplete="current-password"/>
      </div>
      <button type="submit" class="submit-btn">Login to Store →</button>
    </form>
  </div>

  <!-- SIGNUP PANEL -->
  <div class="panel" id="panel-signup">
    <h2>Create Account</h2>
    <p class="sub">Join V² Sports and start shopping!</p>

    <?php if ($error && isset($_POST['action']) && $_POST['action']==='register'): ?>
      <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php">
      <input type="hidden" name="action" value="register">
      <div class="field">
        <label>Full Name</label>
        <input type="text" name="name" placeholder="Your full name" required autocomplete="name"
               value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"/>
      </div>
      <div class="field">
        <label>Email Address</label>
        <input type="email" name="email" placeholder="you@example.com" required autocomplete="email"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"/>
      </div>
      <div class="field">
        <label>Password</label>
        <input type="password" name="password" placeholder="Minimum 6 characters" required autocomplete="new-password"/>
      </div>
      <div class="field">
        <label>Confirm Password</label>
        <input type="password" name="confirm_password" placeholder="Re-enter password" required autocomplete="new-password"/>
      </div>
      <button type="submit" class="submit-btn">Create Account →</button>
    </form>
  </div>
</div>

<p class="footer-note">© 2026 V² Sports, Hyderabad | All Rights Reserved</p>

<script>
// Auto-switch to signup tab if register error
<?php if (isset($_POST['action']) && $_POST['action'] === 'register' && $error): ?>
  window.onload = () => switchTab('signup');
<?php elseif ($success): ?>
  window.onload = () => switchTab('login');
<?php endif; ?>

function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.getElementById('tab-'   + tab).classList.add('active');
  document.getElementById('panel-' + tab).classList.add('active');
}
</script>
</body>
</html>
