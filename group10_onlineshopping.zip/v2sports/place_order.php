<?php
// ── Place Order handler ─────────────────────────────────
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
    exit;
}

$user_email     = mysqli_real_escape_string($conn, $_SESSION['user_email'] ?? 'guest');
$full_name      = mysqli_real_escape_string($conn, $_POST['full_name']      ?? '');
$mobile         = mysqli_real_escape_string($conn, $_POST['mobile']         ?? '');
$pincode        = mysqli_real_escape_string($conn, $_POST['pincode']        ?? '');
$address        = mysqli_real_escape_string($conn, $_POST['address']        ?? '');
$city           = mysqli_real_escape_string($conn, $_POST['city']           ?? '');
$state          = mysqli_real_escape_string($conn, $_POST['state']          ?? '');
$payment_method = mysqli_real_escape_string($conn, $_POST['payment_method'] ?? 'cod');
$total          = floatval($_POST['total'] ?? 0);
$items_json     = $_POST['items'] ?? '[]';

// Validate required fields
if (!$full_name || !$mobile || !$pincode || !$address || !$city || !$state) {
    echo json_encode(["status" => "error", "message" => "All delivery details are required."]);
    exit;
}
if (!preg_match('/^\d{10}$/', $mobile)) {
    echo json_encode(["status" => "error", "message" => "Enter a valid 10-digit mobile number."]);
    exit;
}
if (!preg_match('/^\d{6}$/', $pincode)) {
    echo json_encode(["status" => "error", "message" => "Enter a valid 6-digit pincode."]);
    exit;
}

// Insert order
$sql_order = "INSERT INTO orders (user_email, full_name, mobile, pincode, address, city, state, payment_method, total, status)
              VALUES ('$user_email','$full_name','$mobile','$pincode','$address','$city','$state','$payment_method','$total','Pending')";

if (!mysqli_query($conn, $sql_order)) {
    echo json_encode(["status" => "error", "message" => "Failed to place order."]);
    exit;
}

$order_id = mysqli_insert_id($conn);

// Insert order items
$items = json_decode($items_json, true);
if (is_array($items)) {
    foreach ($items as $item) {
        $pname = mysqli_real_escape_string($conn, $item['name']  ?? '');
        $price = floatval($item['price'] ?? 0);
        $qty   = intval($item['qty']    ?? 1);
        mysqli_query($conn, "INSERT INTO order_items (order_id, product_name, price, quantity)
                             VALUES ('$order_id','$pname','$price','$qty')");
    }
}

echo json_encode([
    "status"   => "success",
    "message"  => "Order placed successfully!",
    "order_id" => $order_id,
    "address"  => "$full_name, $address, $city, $state - $pincode"
]);
mysqli_close($conn);
?>