<?php
// ── Get all products as JSON ────────────────────────────
header('Content-Type: application/json');
require_once 'db.php';

$category = mysqli_real_escape_string($conn, $_GET['category'] ?? '');

if ($category) {
    $result = mysqli_query($conn, "SELECT * FROM products WHERE category='$category' ORDER BY id ASC");
} else {
    $result = mysqli_query($conn, "SELECT * FROM products ORDER BY id ASC");
}

$products = [];
while ($row = mysqli_fetch_assoc($result)) {
    $products[] = $row;
}
echo json_encode(["status" => "success", "products" => $products]);
mysqli_close($conn);
?>