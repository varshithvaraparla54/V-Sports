<?php
// ── Contact / Feedback form handler ────────────────────
header('Content-Type: application/json');
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
    exit;
}

$name    = trim(mysqli_real_escape_string($conn, $_POST['name']    ?? ''));
$email   = trim(mysqli_real_escape_string($conn, $_POST['email']   ?? ''));
$message = trim(mysqli_real_escape_string($conn, $_POST['message'] ?? ''));

if (!$name || !$email || !$message) {
    echo json_encode(["status" => "error", "message" => "All fields are required."]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => "error", "message" => "Invalid email address."]);
    exit;
}

$sql = "INSERT INTO contact_messages (name, email, message) VALUES ('$name','$email','$message')";

if (mysqli_query($conn, $sql)) {
    echo json_encode(["status" => "success", "message" => "Your message has been sent! We'll reply within 24 hours."]);
} else {
    echo json_encode(["status" => "error", "message" => "Could not send message. Please try again."]);
}
mysqli_close($conn);
?>