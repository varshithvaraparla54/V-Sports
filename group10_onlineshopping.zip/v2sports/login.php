<?php
// ── Login user ──────────────────────────────────────────
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
    exit;
}

$email = trim(mysqli_real_escape_string($conn, $_POST['email']    ?? ''));
$pass  = trim($_POST['password'] ?? '');

if (!$email || !$pass) {
    echo json_encode(["status" => "error", "message" => "Email and password are required."]);
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' LIMIT 1");
$user   = mysqli_fetch_assoc($result);

if ($user && password_verify($pass, $user['password'])) {
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_name']  = $user['name'];
    echo json_encode([
        "status"  => "success",
        "message" => "Welcome back, " . $user['name'] . "!",
        "name"    => $user['name']
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid email or password."]);
}
mysqli_close($conn);
?>