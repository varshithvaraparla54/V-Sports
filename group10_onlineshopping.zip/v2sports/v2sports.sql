-- ============================================================
--  V2 Sports Database Setup
--  Run this in phpMyAdmin > SQL tab  OR  via MySQL CLI
-- ============================================================

CREATE DATABASE IF NOT EXISTS v2sports
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE v2sports;

-- ── Users ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(120)  NOT NULL,
    email      VARCHAR(180)  NOT NULL UNIQUE,
    password   VARCHAR(255)  NOT NULL,
    created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── Products ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(150)  NOT NULL,
    category   VARCHAR(60)   NOT NULL,
    price      DECIMAL(10,2) NOT NULL,
    old_price  DECIMAL(10,2) DEFAULT NULL,
    image      VARCHAR(255)  NOT NULL,
    discount   VARCHAR(20)   DEFAULT NULL,
    created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── Orders ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    user_email     VARCHAR(180)  NOT NULL,
    full_name      VARCHAR(120)  NOT NULL,
    mobile         VARCHAR(15)   NOT NULL,
    pincode        VARCHAR(10)   NOT NULL,
    address        TEXT          NOT NULL,
    city           VARCHAR(80)   NOT NULL,
    state          VARCHAR(80)   NOT NULL,
    payment_method VARCHAR(40)   NOT NULL DEFAULT 'cod',
    total          DECIMAL(10,2) NOT NULL,
    status         VARCHAR(40)   NOT NULL DEFAULT 'Pending',
    created_at     TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── Order Items ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS order_items (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    order_id     INT           NOT NULL,
    product_name VARCHAR(150)  NOT NULL,
    price        DECIMAL(10,2) NOT NULL,
    quantity     INT           NOT NULL DEFAULT 1,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── Contact Messages ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS contact_messages (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    name    VARCHAR(120) NOT NULL,
    email   VARCHAR(180) NOT NULL,
    message TEXT         NOT NULL,
    sent_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── Sample Products ──────────────────────────────────────
INSERT INTO products (name, category, price, old_price, image, discount) VALUES
('Cricket Bat',          'cricket',  1050.00, 1500.00, 'images/cricketbat.jpeg',          '30% OFF'),
('Cricket Ball',         'cricket',   500.00,    NULL, 'images/cricketball.jpeg',          NULL),
('Batting Gloves',       'cricket',   819.00,    NULL, 'images/batinggloves.png',          NULL),
('Pads',                 'cricket',   738.00,  979.00, 'images/pads.png',                  '20% OFF'),
('Helmet',               'cricket',   699.00,    NULL, 'images/helmet.png',                NULL),
('Cricket Jersey',       'cricket',   600.00,  800.00, 'images/cricketjersy.png',          '25% OFF'),
('Cricket Kit Bag',      'cricket',   800.00,    NULL, 'images/cricketkitbag.png',         NULL),
('Badminton Racket',     'badminton', 900.00,    NULL, 'images/batmentionracket.jpeg',     NULL),
('Shuttlecocks',         'badminton', 300.00,    NULL, 'images/shuttlecocks.png',          NULL),
('Badminton Net',        'badminton', 700.00,    NULL, 'images/shuttlenet.png',            NULL),
('Badminton Shoes',      'badminton',1500.00, 2000.00, 'images/badmentionshoes.png',       '25% OFF'),
('Training Kit',         'badminton',1200.00, 2999.00, 'images/trainingkit.png',           '60% OFF'),
('Football',             'football',  800.00,    NULL, 'images/football.jpeg',             NULL),
('Football Shoes',       'football', 1440.00, 1800.00, 'images/footballshoes.png',         '20% OFF'),
('Shin Guards',          'football',  650.00,    NULL, 'images/shinguards.png',            NULL),
('Goalkeeper Gloves',    'football',  720.00,    NULL, 'images/goalkeepergloves.png',      NULL),
('Goal Net',             'football',  795.00, 1225.00, 'images/goalnet.png',               '35% OFF'),
('Football Socks',       'football',   54.00,    NULL, 'images/footballsocks.png',         NULL),
('Dumbbells',            'gym',      1200.00,    NULL, 'images/dumbells.jpeg',             NULL),
('Barbell',              'gym',      1250.00,    NULL, 'images/barbell.png',               NULL),
('Treadmill',            'gym',      6200.00,    NULL, 'images/treadmill.png',             NULL),
('Exercise Bike',        'gym',      2590.00, 3700.00, 'images/exercisebike.png',          '30% OFF'),
('Kettlebell',           'gym',       600.00,    NULL, 'images/kettlebell.png',            NULL),
('Yoga Mat',             'gym',       700.00,    NULL, 'images/yogamat.png',               NULL),
('Skipping Rope',        'gym',       300.00,    NULL, 'images/skippingrope.png',          NULL),
('Workout Bench',        'gym',       600.00, 1200.00, 'images/workoutbench.png',          '50% OFF'),
('Pull-Up Bar',          'gym',       800.00,    NULL, 'images/pullupbar.png',             NULL),
('Running Shoes',        'gym',      2000.00,    NULL, 'images/runningshoes.png',          NULL),
('Basketball',           'gym',       900.00,    NULL, 'images/basketball.png',            NULL);
