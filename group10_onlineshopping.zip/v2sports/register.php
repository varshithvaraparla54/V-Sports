<?php
// ── Register new user ──────────────────────────────────
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
    exit;
}

$name  = trim(mysqli_real_escape_string($conn, $_POST['name']  ?? ''));
$email = trim(mysqli_real_escape_string($conn, $_POST['email'] ?? ''));
$pass  = trim($_POST['password'] ?? '');

if (!$name || !$email || !$pass) {
    echo json_encode(["status" => "error", "message" => "All fields are required."]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => "error", "message" => "Invalid email address."]);
    exit;
}

if (strlen($pass) < 6) {
    echo json_encode(["status" => "error", "message" => "Password must be at least 6 characters."]);
    exit;
}

// Check duplicate
$check = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
if (mysqli_num_rows($check) > 0) {
    echo json_encode(["status" => "error", "message" => "Email already registered. Please login."]);
    exit;
}

$hashed = password_hash($pass, PASSWORD_BCRYPT);
$sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$hashed')";

if (mysqli_query($conn, $sql)) {
    $_SESSION['user_email'] = $email;
    $_SESSION['user_name']  = $name;
    echo json_encode(["status" => "success", "message" => "Registration successful! Welcome, $name."]);
} else {
    echo json_encode(["status" => "error", "message" => "Registration failed. Please try again."]);
}
mysqli_close($conn);
?>